import os

class Settings:
    PROJECT_NAME: str = "Conto Mágico"
    VERSION: str = "1.0.0"
    DEBUG: bool = True

settings = Settings()
