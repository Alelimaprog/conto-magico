# config/email.py

def enviar_email(assunto: str, corpo: str):
    print(f"[DEBUG] E-mail simulado: {assunto} - {corpo[:50]}...")
