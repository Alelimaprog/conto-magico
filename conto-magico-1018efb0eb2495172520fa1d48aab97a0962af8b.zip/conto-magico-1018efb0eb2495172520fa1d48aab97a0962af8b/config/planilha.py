# config/planilha.py

def adicionar_historico(historia: str):
    print("[DEBUG] História registrada na planilha (simulado).")
