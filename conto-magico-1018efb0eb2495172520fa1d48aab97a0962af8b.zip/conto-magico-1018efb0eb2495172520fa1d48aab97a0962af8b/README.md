# Conto Mágico - Deployment Instructions

1. Set environment variables
2. Deploy to Railway
3. Link Twilio, ElevenLabs, MercadoPago
4. Connect Google Sheets for subscriber control